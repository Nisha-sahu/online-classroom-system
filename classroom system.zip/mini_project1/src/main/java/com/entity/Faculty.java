package com.entity;

public class Faculty {
         private int id;
         private String name;
         private String email;
         private String qualification;
         private String designation;
         private String address;
         private String contact;
         private String password;
         private String doj;
         private String role;
         
         public Faculty() {
 			super();
 			// TODO Auto-generated constructor stub
 		}
 		
         
         public Faculty(String name, String email, String qualification, String designation, String address, String contact,
 				String password, String doj, String role) {
 			super();
 			this.name = name;
 			this.email = email;
 			this.qualification = qualification;
 			this.designation = designation;
 			this.address = address;
 			this.contact = contact;
 			this.password = password;
 			this.doj = doj;
 			this.role = role;
 		}
         
		public int getId() {
 			return id;
 		}
 		public void setId(int id) {
 			this.id = id;
 		}
 		
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getQualification() {
			return qualification;
		}
		public void setQualification(String qualification) {
			this.qualification = qualification;
		}
		public String getDesignation() {
			return designation;
		}
		public void setDesignation(String designation) {
			this.designation = designation;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getContact() {
			return contact;
		}
		public void setContact(String contact) {
			this.contact = contact;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getDoj() {
			return doj;
		}
		public void setDoj(String doj) {
			this.doj = doj;
		}
		public String getRole() {
			return role;
		}
		public void setRole(String role) {
			this.role = role;
		}
         
         
		}
