package com.entity;

public class Student {
         private int id;
         private String name;
         private String password;
         private String course;
         private String semester;
         private String roll;
         private String contact;
         private String address;
         private String role;
         
         
         
		public Student() {
			super();
			// TODO Auto-generated constructor stub
		}
		public Student(String name, String password, String course, String semester, String roll, String contact,
				String address, String role) {
			super();
			this.name = name;
			this.password = password;
			this.course = course;
			this.semester = semester;
			this.roll = roll;
			this.contact = contact;
			this.address = address;
			this.role = role;
			
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getCourse() {
			return course;
		}
		public void setCourse(String course) {
			this.course = course;
		}
		public String getSemester() {
			return semester;
		}
		public void setSemester(String semester) {
			this.semester = semester;
		}
		public String getRoll() {
			return roll;
		}
		public void setRoll(String roll) {
			this.roll = roll;
		}
		public String getContact() {
			return contact;
		}
		public void setContact(String contact) {
			this.contact = contact;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getRole() {
			return role;
		}
		public void setRole(String role) {
			this.role = role;
		}
		
}
