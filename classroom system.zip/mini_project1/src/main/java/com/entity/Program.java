package com.entity;

public class Program {
	private int id;
    
    private String subject;
    private String course;
    private String duration;
    private String semester;
	public Program() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Program(String subject, String course, String duration, String semester) {
		super();
		this.subject = subject;
		this.course = course;
		this.duration = duration;
		this.semester = semester;
	}
	
	

	public Program(int id, String subject, String course, String duration, String semester) {
		super();
		this.id = id;
		this.subject = subject;
		this.course = course;
		this.duration = duration;
		this.semester = semester;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getSemester() {
		return semester;
	}
	public void setSemester(String semester) {
		this.semester = semester;
	}
    

}
