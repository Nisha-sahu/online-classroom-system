package com.admin.servlet;
import java.io.IOException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.ProgramDao;
import com.db.DBConnect;
import com.entity.Program;

@WebServlet("/updateCourse")
public class UpdateCourse extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String subject=req.getParameter("subject");
			String course=req.getParameter("course");
			String duration=req.getParameter("duration");
			String semester=req.getParameter("semester");
			
			int id=Integer.parseInt(req.getParameter("id"));
			
			Program p=new Program(id,subject,course,duration,semester);
			ProgramDao dao=new ProgramDao(DBConnect.getConn());
			HttpSession session=req.getSession();
			if(dao.updateProgram(p))
			{
				session.setAttribute("succMsg", "course updated successfully");
				resp.sendRedirect("courses.jsp");
			}else {
				session.setAttribute("errorMsg", "something wrong");
				resp.sendRedirect("courses.jsp");
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}

