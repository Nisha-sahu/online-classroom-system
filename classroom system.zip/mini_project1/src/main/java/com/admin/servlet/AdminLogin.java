package com.admin.servlet;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.entity.Student;

@WebServlet("/adminLogin")
public class AdminLogin extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			
			    String uname = req.getParameter("uname");
				String password = req.getParameter("pass");
				
				HttpSession session = req.getSession();

				if ("admin".equals(uname) && "123".equals(password)) {
					session.setAttribute("adminObj", new Student());
					resp.sendRedirect("admin_dashboard.jsp");
				} else {
					session.setAttribute("errorMsg", "invalid username & password");
					resp.sendRedirect("alogin.jsp");
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}