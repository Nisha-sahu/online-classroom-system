package com.admin.servlet;
import java.io.IOException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.dao.CategoryDao;
import com.db.DBConnect;
import com.entity.Category;

import javax.servlet.http.HttpSession;

@WebServlet("/addCategory")
public class AddCategory extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String name=req.getParameter("name");
			
			Category c=new Category(name);
			CategoryDao dao=new CategoryDao(DBConnect.getConn());
			HttpSession session=req.getSession();
			if(dao.registerCategory(c))
			{
				session.setAttribute("succMsg", "category added successfully");
				resp.sendRedirect("category.jsp");
			}else {
				session.setAttribute("errorMsg", "something wrong");
				resp.sendRedirect("category.jsp");
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
          
}




