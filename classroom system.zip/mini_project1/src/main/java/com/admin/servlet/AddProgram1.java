package com.admin.servlet;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/addProgram1")
public class AddProgram1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
  

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String course=request.getParameter("course");
		String pname=request.getParameter("program");
		String duration=request.getParameter("duration");
		String semester=request.getParameter("semester");
		int fid=Integer.parseInt(request.getParameter("fid"));
		String fname=request.getParameter("fname");

		Connection con=null;
		RequestDispatcher dispatcher=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		 con=DriverManager.getConnection("jdbc:mysql://localhost:3306/userdb","root","nisha2023");
		PreparedStatement pst=con.prepareStatement("insert into program(fid,fname,course,pname,duration,semester)values(?,?,?,?,?,?)");
		pst.setInt(1, fid);
		pst.setString(2, fname);
		
		pst.setString(3, course);
		pst.setString(4, pname);
		pst.setString(5, duration);
		pst.setString(6, semester);
		   
		int rows=pst.executeUpdate();
		dispatcher=request.getRequestDispatcher("program.jsp");
		if(rows>0)
		{
		request.setAttribute("status", "success");	
		
		}
		else
		{
			request.setAttribute("status", "failed");
			
		}
		dispatcher.forward(request, response);
	}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		

		
		
	}

}
