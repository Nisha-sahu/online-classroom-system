package com.user.servlet;

import java.io.IOException;

import java.sql.*;

import javax.servlet.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/facultyRegister")
public class FacultyRegister1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doPost(HttpServletRequest req, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		String name=req.getParameter("name");
		String email=req.getParameter("email");
		String qualification=req.getParameter("qualification");
		String designation=req.getParameter("desc");
		String address=req.getParameter("address");
		String contact=req.getParameter("contact");
		String password=req.getParameter("pass");
		String doj=req.getParameter("date");
		String role=req.getParameter("role");
		
		Connection con=null;
	RequestDispatcher dispatcher=null;
	try {
		Class.forName("com.mysql.jdbc.Driver");
	 con=DriverManager.getConnection("jdbc:mysql://localhost:3306/userdb","root","nisha2023");
	PreparedStatement pst=con.prepareStatement("insert into faculty(name,email,qualification,designation,address,contact,password,doj,role)values(?,?,?,?,?,?,?,?,?)");
	pst.setString(1,name);
	pst.setString(2,email);
	pst.setString(3,qualification);
	pst.setString(4,designation);
	pst.setString(5,address);
	pst.setString(6,contact);
	pst.setString(7,password);
	pst.setString(8,doj);
	pst.setString(9,role);

	int rows=pst.executeUpdate();
	dispatcher=req.getRequestDispatcher("flogin.jsp");
	if(rows>0)
	{
	req.setAttribute("status", "success");	
	
	}
	else
	{
		req.setAttribute("status", "failed");
		
	}
	dispatcher.forward(req, response);
}
	catch(Exception e)
	{
		e.printStackTrace();
		
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	}
}

