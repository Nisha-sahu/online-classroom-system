package com.user.servlet;

import java.io.IOException;

import java.sql.*;

import javax.servlet.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/studentRegister")
public class StudentRegister1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doPost(HttpServletRequest req, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		String name=req.getParameter("name");
		String email=req.getParameter("email");
		String password=req.getParameter("pass");
		String program=req.getParameter("program");
		String semester=req.getParameter("sem");
		String roll=req.getParameter("roll");
		String contact=req.getParameter("cont");
		String address=req.getParameter("address");
		String role=req.getParameter("role");
		
		Connection con=null;
	RequestDispatcher dispatcher=null;
	try {
		Class.forName("com.mysql.jdbc.Driver");
	 con=DriverManager.getConnection("jdbc:mysql://localhost:3306/userdb","root","nisha2023");
	PreparedStatement pst=con.prepareStatement("insert into student1(name,email,password,pname,semester,roll,contact,address,role)values(?, ?, ?, ?, ?, ?, ?, ?, ?)");
	pst.setString(1,name);
	pst.setString(2,email);
	pst.setString(3,password);
	pst.setString(4,program);
	pst.setString(5,semester);
	pst.setString(6,roll);
	pst.setString(7,contact);
	pst.setString(8,address);
	pst.setString(9,role);
	

	int rows=pst.executeUpdate();
	dispatcher=req.getRequestDispatcher("slogin.jsp");
	if(rows>0)
	{
	req.setAttribute("status", "success");	
	
	}
	else
	{
		req.setAttribute("status", "failed");
		
	}
	dispatcher.forward(req, response);
}
	catch(Exception e)
	{
		e.printStackTrace();
		
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	}
}


