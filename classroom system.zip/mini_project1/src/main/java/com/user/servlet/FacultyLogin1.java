package com.user.servlet;

import java.io.IOException;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/loginServlet")
public class FacultyLogin1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest req, HttpServletResponse response) throws ServletException, IOException {
	
		String email = req.getParameter("email");
		String password = req.getParameter("pass");
		String role = req.getParameter("role");
		Connection con=null;
		HttpSession session=req.getSession();
		RequestDispatcher dispatcher=null;
		try { 
			
			Class.forName("com.mysql.jdbc.Driver");
			 con=DriverManager.getConnection("jdbc:mysql://localhost:3306/userdb","root","nisha2023");
			 PreparedStatement pst=con.prepareStatement("select * from faculty where email= ? and password= ? and role=?");
				pst.setString(1, email);
				pst.setString(2, password);
				pst.setString(3, role);
				
				ResultSet rs=pst.executeQuery();
				if(rs.next()) {
					session.setAttribute("email", rs.getString("email"));
					dispatcher=req.getRequestDispatcher("faculty_dashboard.jsp");
				}
				else
				{
					dispatcher=req.getRequestDispatcher("flogin.jsp");
					req.setAttribute("error", "Invalid credentials...!!");
				}
				dispatcher.forward(req, response);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
	}

}
