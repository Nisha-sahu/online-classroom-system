package com.servlet;
import java.io.IOException;

import java.io.File;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.db.DBConnect;



@WebServlet("/uploadfile")
@MultipartConfig


public class UploadFile extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String course= req.getParameter("course");
		String category= req.getParameter("category");
		String program= req.getParameter("program");
		String semester= req.getParameter("sem");
		String fname= req.getParameter("fname");
		Part p = req.getPart("files");
		String fileName = p.getSubmittedFileName();


		HttpSession session = req.getSession();

		try {
             
			Connection conn = DBConnect.getConn();

			PreparedStatement ps = conn.prepareStatement("insert into material(course,category,pname,semester,file,fname) values(?,?,?,?,?,?)");
			ps.setString(1, course);
			ps.setString(2, category);
			ps.setString(3, program);
			ps.setString(4, semester);
			
			ps.setString(5, fileName);
			ps.setString(6, fname);

			int i = ps.executeUpdate();

			if (i == 1) {

				String path = getServletContext().getRealPath("") + "imgs";

				File file = new File(path);

				p.write(path + File.separator + fileName);

				session.setAttribute("msg", "Successfully uploaded");

				resp.sendRedirect("upload.jsp");

			} else {
				System.out.println("Error in server");
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	}
         

