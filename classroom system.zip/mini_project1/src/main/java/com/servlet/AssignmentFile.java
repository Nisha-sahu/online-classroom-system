package com.servlet;
import java.io.IOException;

import java.io.File;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.db.DBConnect;



@WebServlet("/assig")
@MultipartConfig


public class AssignmentFile extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String name= req.getParameter("name");
		String roll= req.getParameter("roll");
		String pname= req.getParameter("program");
		String course= req.getParameter("course");
		String semester= req.getParameter("sem");
		Part p = req.getPart("files");
		String fileName = p.getSubmittedFileName();


		HttpSession session = req.getSession();

		try {
             
			Connection conn = DBConnect.getConn();

			PreparedStatement ps = conn.prepareStatement("insert into assignment(name,roll,pname,course,semester,file) values(?,?,?,?,?,?)");
			ps.setString(1, name);
			ps.setString(2, roll);
			ps.setString(3, pname);
			ps.setString(4, course);
			ps.setString(5, semester);
			ps.setString(6, fileName);
			

			int i = ps.executeUpdate();

			if (i == 1) {

				String path = getServletContext().getRealPath("") + "imgs";

				File file = new File(path);

				p.write(path + File.separator + fileName);

				session.setAttribute("msg", "Successfully uploaded");

				resp.sendRedirect("assignment.jsp");

			} else {
				System.out.println("Error in server");
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	}
         

