package com.servlet;
import java.io.IOException;
import java.io.OutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.db.DBConnect;



@WebServlet("/downloadfile")
@MultipartConfig

public class DownloadFile extends HttpServlet{
	
	public int BUFFER_SIZE=1024*1000;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
		String fileName = req.getParameter("fn");
		String path = getServletContext().getRealPath(" ") + "imgs" + File.separator + fileName;
		File file=new File(path);
		OutputStream os=null;
		FileInputStream fis=null;
		if(file.exists())
		{
			resp.setHeader("Content-Disposition", String.format("attachment;filename=\"%s\"", file.getName()));
			resp.setContentType("application/octet-stream");
			
			os=resp.getOutputStream();
			fis=new FileInputStream(file);
			byte[] b=new byte[BUFFER_SIZE];
			int byteRead=-1;
			while((byteRead=fis.read(b))!=-1)
			{
				os.write(b,0,byteRead);
			}
		}else {
			resp.setContentType("text/html");
			resp.getWriter().print("<h4>Image not found with=" + fileName +"</h4>");
		}

	}
}