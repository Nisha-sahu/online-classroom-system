package com.dao;
import com.entity.Category;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.ArrayList;



public class CategoryDao {
	private Connection conn;

	public CategoryDao(Connection conn) {
		super();
		this.conn=conn;
		
	}
	public boolean registerCategory(Category c) {
 	   boolean f=false;
 	   try {
 		   String sql="insert into category(name) values(?)";
 		   PreparedStatement ps=conn.prepareStatement(sql);
 		   ps.setString(1, c.getName());
 		   
 		   int i=ps.executeUpdate();
 		   if(i==1)
 		   {
 			   f=true;
 		   }
 	   }catch(Exception e) {
 		   e.printStackTrace();
 	   }
 	   return f;
    }
    public List<Category> getAllCategory()
    {
 	   List<Category> list=new ArrayList<Category>();
 	   Category c=null;
 	   try {
 		   String sql="select * from category";
 		   PreparedStatement ps=conn.prepareStatement(sql);
 		   ResultSet rs=ps.executeQuery();
 		   while(rs.next())
 		   {
 			   c=new Category();
 			   c.setId(rs.getInt(1));
 			   c.setName(rs.getString(2));
 			   
 			   list.add(c);
 			   
 			   
 		   }
 		   
 	   }catch(Exception e) {
 		   e.printStackTrace();
 	   }
 	   return list;
    }
    
    
}

	
	


