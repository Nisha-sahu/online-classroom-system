package com.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.entity.Faculty;
import com.entity.Student;
public class StudentDao {
        private Connection conn;

		public StudentDao(Connection conn) {
			super();
			this.conn = conn;
		}
     public boolean studentregister(Student s)
     {
    	 boolean f=false;
    	 try {
    		 String sql="insert into student (name,password,course,semester,roll,contact,address,role)values(?, ?, ?, ?, ?, ?, ?, ?)";
    			
    		 PreparedStatement ps=conn.prepareStatement(sql);
    		 ps.setString(1,s.getName());
    			ps.setString(2,s.getPassword());
    			ps.setString(3,s.getCourse());
    			ps.setString(4,s.getSemester());
    			ps.setString(5,s.getRoll());
    			ps.setString(6,s.getContact());
    			ps.setString(7,s.getAddress());
    			ps.setString(8,s.getRole());
    			
    			int i=ps.executeUpdate();
    			if(i==1)
    			{
    				f=true;
    			}
    			
    		 
    	 }catch (Exception e) {
    		 e.printStackTrace();
    	 }
    	 return f;
     }
     
     public Student login(String un,String pw, String rl)
     {
    	 Student s=null;
    	 try {
    		 String sql="select * from student where name=?,password=? and role=?";
    		 PreparedStatement ps=conn.prepareStatement(sql);
    		 ps.setString(1, un);
    		 ps.setString(2, pw);
    		 ps.setString(3, rl);
    		 ResultSet rs=ps.executeQuery();
    		 while(rs.next())
    		 {
    			 s=new Student();
    			 s.setId(rs.getInt(1));
    			 s.setName(rs.getString(2));
    			 s.setPassword(rs.getString(3));
    			 s.setCourse(rs.getString(4));
    			 s.setSemester(rs.getString(5));
    			 s.setRoll(rs.getString(6));
    			 s.setContact(rs.getString(7));
    			 s.setAddress(rs.getString(8));
    			 s.setRole(rs.getString(9));
    			
    			 
    		 }
    		 
    	 }catch(Exception e) {
    		 e.printStackTrace();
    	 }
    	 return s;
     }
     public List<Student>getAllStudent()
     {
  	   List<Student> list=new ArrayList<Student>();
  	   Student s=null;
  	   try {
  		   String sql="select * from student order by id";
  		   PreparedStatement ps=conn.prepareStatement(sql);
  		   ResultSet rs=ps.executeQuery();
  		   while(rs.next())
  		   {
  			   s=new Student();
  			   s.setId(rs.getInt(1));
  			   s.setName(rs.getString(2));
  			   s.setPassword(rs.getString(3));
  			   s.setCourse(rs.getString(4));
  			 s.setSemester(rs.getString(5));
  			s.setRoll(rs.getString(6));
  			s.setContact(rs.getString(7));
  			s.setAddress(rs.getString(8));
  			s.setRole(rs.getString(9));
  			
  			   list.add(s);
  			   
  			   
  		   }
  		   
  	   }catch(Exception e) {
  		   e.printStackTrace();
  	   }
  	   return list;
     }
 }


		        



		        

