package com.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.entity.Faculty;
import com.entity.Program;

public class FacultyDao {
        private Connection conn;

		public FacultyDao(Connection conn) {
			super();
			this.conn = conn;
		}
     public boolean facultyregister(Faculty f)
     {
    	 boolean fi=false;
    	 try {
    		 String sql="insert into faculty (name,email,qualification,designation,address,contact,password,doj,role)values(?, ?, ?, ?, ?, ?, ?, ?, ?)";
    			
    		 PreparedStatement ps=conn.prepareStatement(sql);
    		 ps.setString(1,f.getName());
    			ps.setString(2,f.getEmail());
    			ps.setString(3,f.getQualification());
    			ps.setString(4,f.getDesignation());
    			ps.setString(5,f.getAddress());
    			ps.setString(6,f.getContact());
    			ps.setString(7,f.getPassword());
    			ps.setString(8,f.getDoj());
    			ps.setString(9,f.getRole());
    			
    			int i=ps.executeUpdate();
    			if(i==1)
    			{
    				fi=true;
    			}
    			
    		 
    	 }catch (Exception e) {
    		 e.printStackTrace();
    	 }
    	 return fi;
     }
     
     public Faculty login(String un,String pw, String rl)
     {
    	 Faculty f=null;
    	 try {
    		 String sql="select * from faculty where email= ?,password= ? and role= ?";
    		 Statement st=conn.createStatement();
       		 ResultSet rs=st.executeQuery("select * from faculty where email='"+un+"' ,'"+pw+"','"+rl+"'");
    		 while(rs.next())
    		 {
    			 f=new Faculty();
    			 f.setId(rs.getInt(1));
    			 f.setName(rs.getString(2));
    			 f.setEmail(rs.getString(3));
    			 f.setQualification(rs.getString(4));
    			 f.setDesignation(rs.getString(5));
    			 f.setAddress(rs.getString(6));
    			 f.setContact(rs.getString(7));
    			 f.setPassword(rs.getString(8));
    			 f.setDoj(rs.getString(9));
    			 f.setRole(rs.getString(10));
    			
    			 
    		 }
    		 
    	 }catch(Exception e) {
    		 e.printStackTrace();
    	 }
    	 
    	 
    	 return f;
     }
     public List<Faculty> getAllFaculty()
     {
  	   List<Faculty> list=new ArrayList<Faculty>();
  	   Faculty f=null;
  	   try {
  		   String sql="select * from faculty order by id";
  		   PreparedStatement ps=conn.prepareStatement(sql);
  		   ResultSet rs=ps.executeQuery();
  		   while(rs.next())
  		   {
  			   f=new Faculty();
  			   f.setId(rs.getInt(1));
  			   f.setName(rs.getString(2));
  			   f.setEmail(rs.getString(3));
  			   f.setQualification(rs.getString(4));
  			 f.setDesignation(rs.getString(5));
  			f.setAddress(rs.getString(6));
  			f.setContact(rs.getString(7));
  			f.setPassword(rs.getString(8));
  			f.setDoj(rs.getString(9));
  			f.setRole(rs.getString(10));
  			   list.add(f);
  			   
  			   
  		   }
  		   
  	   }catch(Exception e) {
  		   e.printStackTrace();
  	   }
  	   return list;
     }
 }


		        


