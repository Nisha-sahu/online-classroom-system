package com.dao;
import com.entity.Program;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.ArrayList;



public class ProgramDao {
	private Connection conn;

	public ProgramDao(Connection conn) {
		super();
		this.conn=conn;
		
	}
	public boolean registerProgram(Program p) {
 	   boolean f=false;
 	   try {
 		   String sql="insert into course(subject,course,duration,semester) values(?, ?, ?, ?)";
 		   PreparedStatement ps=conn.prepareStatement(sql);
 		   ps.setString(1, p.getSubject());
 		   ps.setString(2, p.getCourse());
 		   ps.setString(3, p.getDuration());
 		  ps.setString(4, p.getSemester());
 		   
 		   int i=ps.executeUpdate();
 		   if(i==1)
 		   {
 			   f=true;
 		   }
 	   }catch(Exception e) {
 		   e.printStackTrace();
 	   }
 	   return f;
    }
    public List<Program> getAllProgram()
    {
 	   List<Program> list=new ArrayList<Program>();
 	   Program p=null;
 	   try {
 		   String sql="select * from course order by id";
 		   PreparedStatement ps=conn.prepareStatement(sql);
 		   ResultSet rs=ps.executeQuery();
 		   while(rs.next())
 		   {
 			   p=new Program();
 			   p.setId(rs.getInt(1));
 			   p.setSubject(rs.getString(2));
 			   p.setCourse(rs.getString(3));
 			   p.setDuration(rs.getString(4));
 			  p.setSemester(rs.getString(5));
 			   list.add(p);
 			   
 			   
 		   }
 		   
 	   }catch(Exception e) {
 		   e.printStackTrace();
 	   }
 	   return list;
    }
    
    public Program getProgramById(int id)
    {
 	   
 	   Program p=null;
 	   try {
 		   String sql="select * from course where id=?";
 		   PreparedStatement ps=conn.prepareStatement(sql);
 		   ps.setInt(1, id);
 		   ResultSet rs=ps.executeQuery();
 		   while(rs.next())
 		   {
 			   p=new Program();
 			   p.setId(rs.getInt(1));
 			   p.setSubject(rs.getString(2));
 			   p.setCourse(rs.getString(3));
 			   p.setDuration(rs.getString(4));
 			  p.setSemester(rs.getString(5));
 			  
 			   
 			   
 		   }
 		   
 	   }catch(Exception e) {
 		   e.printStackTrace();
 	   }
 	   return p;
    }
    
    public boolean updateProgram(Program p) {
  	   boolean f=false;
  	   try {
  		   String sql="update course set subject=?,course=?,duration=?,semester=? where id=?";
  		   PreparedStatement ps=conn.prepareStatement(sql);
  		   ps.setString(1, p.getSubject());
  		   ps.setString(2, p.getCourse());
  		   ps.setString(3, p.getDuration());
  		   ps.setInt(4, p.getId());
  		 ps.setString(5, p.getSemester());
  		   
  		   int i=ps.executeUpdate();
  		   if(i==1)
  		   {
  			   f=true;
  		   }
  	   }catch(Exception e) {
  		   e.printStackTrace();
  	   }
  	   return f;
     }
    
    public boolean deleteProgram(int id) {
   	   boolean f=false;
   	   try {
   		   String sql="delete from course where id=?";
   		   PreparedStatement ps=conn.prepareStatement(sql);
   		   ps.setInt(1, id);
   		   
   		   int i=ps.executeUpdate();
   		   if(i==1)
   		   {
   			   f=true;
   		   }
   	   }catch(Exception e) {
   		   e.printStackTrace();
   	   }
   	   return f;
      }
     
     
    
    
    
}

	
	


